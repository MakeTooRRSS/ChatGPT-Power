module.exports = require('@lobehub/lint').remarklint;
