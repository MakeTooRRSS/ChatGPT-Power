export default {
  topic: {
    desc: '点击发送左侧按钮可将当前会话保存为历史话题，并开启新一轮会话',
    title: '话题列表',
  },
};
