export default {
  button: {
    import: '导入配置',
    start: '立即开始',
  },
  header: '欢迎使用',
  pickAgent: '或从下列助手模板选择',
  skip: '跳过创建',
  slogan: {
    desc1: '开启大脑集群，激发思维火花。你的智能助理，一直都在。',
    desc2: '创建你的第一个助手，让我们开始吧~',
    title: '给自己一个更聪明的大脑',
  },
};
