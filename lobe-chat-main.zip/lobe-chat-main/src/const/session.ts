export const INBOX_SESSION_ID = 'inbox';
