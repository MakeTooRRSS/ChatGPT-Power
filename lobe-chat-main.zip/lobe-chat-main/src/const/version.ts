import pkg from '@/../package.json';

export const CURRENT_VERSION = pkg.version;

export const MANUAL_UPGRADE_URL =
  'https://github.com/lobehub/lobe-chat/blob/main/docs/Upstream-Sync.md';
