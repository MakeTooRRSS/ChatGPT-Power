import Index from './index';

export default () => <Index />;
