module.exports = require('@lobehub/lint').changelog;
